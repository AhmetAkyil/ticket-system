﻿using System.ComponentModel.DataAnnotations;
using TicketSystem.Enums;

namespace TicketSystem.Models
{
    public class Ticket
    {
        public long Id { get; set; }
        
        [Required]
        public string Title { get; set; }   
        public string Description { get; set; }
        [Required]
        public TicketStatus Status { get; set; }

        public long CreatedByUserId { get; set; }
        public long? AssignedToUserId { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
