﻿namespace TicketSystem.Enums
{
    public enum TicketStatus
    {
        Open,
        InProgress,
        Resolved
    }
}
